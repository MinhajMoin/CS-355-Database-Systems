﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Form2 mainform = null;
        Form2.Book bk = null;
        public Form1()
        {
            InitializeComponent();
            cat.Items.Add("DataBase Systems");
            cat.Items.Add("Programming");
            cat.Items.Add("Artificial Intelligence");
        }

        public Form1(Form callingform)
        {
            mainform = callingform as Form2;
            InitializeComponent();
            cat.Items.Add("DataBase Systems");
            cat.Items.Add("Programming");
            cat.Items.Add("Artificial Intelligence");
        }

        public void label1_Click(object sender, EventArgs e)
        {

        }

        public void Form1_Load(object sender, EventArgs e)
        {
            if (checkBox1.Enabled == false)
            {
                textBox5.Enabled = false;
                comboBox3.Enabled = false;
            }
            comboBox3.Format = DateTimePickerFormat.Custom;
            comboBox3.CustomFormat = "dd/MMM/yyyy";
        }

        public void edit_book(object sender, EventArgs e)
        {
            bk = this.mainform.bookdic[this.mainform.listBox1.SelectedItem.ToString()];
            bk.Title = textBox2.Text.ToString();
            
            bk.ISBN = textBox1.Text.ToString();
            bk.isIssued = checkBox1.Checked;
            bk.issuedOn = comboBox3.Value;
            bk.issuedTo = textBox5.Text;
            bk.purchasedon = dateTimePicker1.Value;
            string authorlist = "";
            foreach (string author in listBox1.Items)
            {
                if (author == listBox1.Items[(listBox1.Items.Count) - 1]) authorlist += author;
                else authorlist += author + "; ";
            }
            bk.authors = authorlist;
            bk.catIndex = cat.SelectedIndex;
            bk.subcatIndex = subcat.SelectedIndex;
            int book_type = 0;
            if (radioButton2.Checked) book_type = 1;
            else if (radioButton3.Checked) book_type = 2;
            bk.type = book_type;
            if ((this.mainform.bookdic.ContainsKey(bk.Title)) == false)
            {
                this.mainform.bookdic.Add(bk.Title, bk);
                this.mainform.bookdic.Remove(this.mainform.listBox1.SelectedItem.ToString());
            }
            this.mainform.button1_Click_1(sender, e);
            //this.mainform.listBox1.SelectedItem = bk.Title;
        }

        public void add_book()
        {
            string Title = textBox2.Text.ToString();
            string ISBN = textBox1.Text.ToString();
            bool isIssued = checkBox1.Checked;
            DateTime issuedOn = comboBox3.Value;
            String issuedTo = textBox5.Text.ToString();
            DateTime purchasedon = dateTimePicker1.Value;
            string authorlist = "";
            for (int i=0; i < listBox1.Items.Count;i++)
            {
                if (i == listBox1.Items.Count - 1) authorlist += listBox1.Items[i];
                else authorlist += listBox1.Items[i] + "; ";
            }
            int catIndex = cat.SelectedIndex;
            int subcatIndex = subcat.SelectedIndex;
            int book_type = 0;
            if (radioButton2.Checked) book_type = 1;
            else if (radioButton3.Checked) book_type = 2;
            int type = book_type;
            Form2.Book book = new Form2.Book(ISBN, Title, catIndex, subcatIndex,authorlist, purchasedon, type, isIssued, issuedTo, issuedOn);
            this.mainform.books.Add(book);
            this.mainform.bookdic.Add(Title, book);
        }

        public void label2_Click(object sender, EventArgs e)
        {

        }

        public void label5_Click(object sender, EventArgs e)
        {

        }

        public void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void label7_Click(object sender, EventArgs e)
        {

        }

        public void label8_Click(object sender, EventArgs e)
        {

        }

        public void cat_SelectedIndexChanged(object sender, EventArgs e)
        {
            subcat.Items.Clear();
            if (cat.Text == "DataBase Systems")
            {
                subcat.Items.Add("ERD");
                subcat.Items.Add("SQL");
                subcat.Items.Add("Data Mining");
                subcat.Items.Add("OLAP");
            }
            else if (cat.Text == "Programming")
            {
                subcat.Items.Add("C#");
                subcat.Items.Add("Java");
                subcat.Items.Add("Web Programming");
            }
            else if (cat.Text == "Artificial Intelligence")
            {
                subcat.Items.Add("Machine Learning");
                subcat.Items.Add("Robotics");
                subcat.Items.Add("Computer Vision");
            }
        }

        public void addauthor_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox4.Text);
            textBox4.Clear();
        }

        public void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        public void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                textBox5.Enabled = false;
                comboBox3.Enabled = false;
            }
            else
            {
                textBox5.Enabled = true;
                comboBox3.Enabled = true;
            }
        }

        public void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        public void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength == 0)
            {
                MessageBox.Show("Please Input The ISBN of The Book.");
                return;
            }

            else if (textBox1.TextLength < 12)
            {
                MessageBox.Show("ISBN must be a 12-digit Number with the Alphabetical code.");
                return;
            }


            if ((radioButton3.Checked || (listBox1.Items.Count > 0)) == false)
            {
                MessageBox.Show("Please Enter the Name of the Authors of the Journal");
                return;
            }


            if (checkBox1.Checked && textBox5.TextLength == 0)
            {
                MessageBox.Show("Please Enter the Name of the Person to whom this Book has been Issued to");
                return;
            }

            if (dateTimePicker1.Value >= DateTime.Now.AddDays(-1))
            {
                MessageBox.Show("Purchase Date must be earlier than Today");
                return;
            }

            if (checkBox1.Checked && (comboBox3.Value <= dateTimePicker1.Value || comboBox3.Value >= DateTime.Now.AddDays(1)))
            {
                MessageBox.Show("Issue Date must be earlier than Today and later than Purchase Date");
                return;
            }

            if (mainform != null)
            {
                if (this.mainform.form_type == "edit") edit_book(sender, e);
                else if (this.mainform.form_type == "add") add_book();
            }
            this.Close();
        }

        public void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
          
        }

        public void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
