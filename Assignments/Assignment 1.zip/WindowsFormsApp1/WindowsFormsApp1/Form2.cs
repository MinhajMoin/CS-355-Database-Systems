﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {

        public Form2()
        {
            InitializeComponent();
        }
        public class Book
        {
            public string ISBN;
            public string Title;
            public int catIndex;
            public int subcatIndex;
            public string authors;
            public DateTime purchasedon;
            public int type;
            public bool isIssued;
            public string issuedTo;
            public DateTime issuedOn;

            public Book(string _ISBN, string _title, int _cat, int _subcat, string _authors, DateTime _purchasedOn, int _type, bool _isIssued, string _issuedTo, DateTime _issuedDate)
            {
                ISBN = _ISBN;
                Title = _title;
                catIndex = _cat;
                subcatIndex = _subcat;
                authors = _authors;
                purchasedon = _purchasedOn;
                type = _type;
                isIssued = _isIssued;
                issuedTo = _issuedTo;
                issuedOn = _issuedDate;

            }
        }

        public List<Book> books = new List<Book>();

        public Dictionary<string, Book> bookdic = new Dictionary<string, Book>();

        public string form_type = null;

        private void fill_in(object sender, EventArgs e)
        {
            Form1 form=null;
            if (form_type == "edit" || form_type == "add") form = new Form1(this);
            else if (form_type == "view") form = new Form1();
            Book selectedbook = bookdic[listBox1.SelectedItem.ToString()];
            form.textBox1.Text = selectedbook.ISBN;
            form.textBox2.Text = selectedbook.Title;
            form.cat.SelectedIndex = selectedbook.catIndex;
            form.subcat.SelectedIndex = selectedbook.subcatIndex;
            form.dateTimePicker1.Value = selectedbook.purchasedon;
            form.comboBox3.Value = selectedbook.issuedOn;
            form.textBox5.Text = selectedbook.issuedTo;
            form.checkBox1.Checked = selectedbook.isIssued;
            if (selectedbook.isIssued == false)
            {
                form.checkBox1_CheckedChanged(sender, e);
            }
            if (selectedbook.type == 0) form.radioButton1.Checked = true;
            else if (selectedbook.type == 1) form.radioButton2.Checked = true;
            else if (selectedbook.type == 2) form.radioButton3.Checked = true;
            string authors = selectedbook.authors;
            string[] authorlist = authors.Split(new string[] { "; " }, StringSplitOptions.None);
            foreach (string author in authorlist)
            {
                form.listBox1.Items.Add(author);
            }/*
            if (form_type == "view")
            {
                form.textBox1.ReadOnly = true;
                form.textBox1.BackColor = System.Drawing.SystemColors.Window;
                form.textBox2.ReadOnly = true;
                form.textBox2.BackColor = System.Drawing.SystemColors.Window;
                form.textBox4.ReadOnly = true;
                form.textBox4.BackColor = System.Drawing.SystemColors.Window;
                form.textBox5.ReadOnly = true;
                form.textBox5.BackColor = System.Drawing.SystemColors.Window;
                form.cat.Enabled = false;
                form.cat.BackColor = System.Drawing.SystemColors.Window;
                form.subcat.Enabled = false;
                form.subcat.BackColor = System.Drawing.SystemColors.Window;

            }*/
        
            form.ShowDialog();
        }

        private void view_key_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex > -1)
            {
                form_type = "view";
                fill_in(sender, e);
            }

            else MessageBox.Show("Please Select a Book First");
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        public void button1_Click_1(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int k = 0;
            if (radioButton2.Checked == true) k = 1;
            else if (radioButton3.Checked == true) k = 2;
            for (int i=0;i<books.Count();i++)
            {
                if (books[i].catIndex == comboBox1.SelectedIndex && (books[i].Title.ToLower().Contains(textBox1.Text.ToLower()) || textBox1.Text.Length==0) && k == books[i].type)
                {
                    listBox1.Items.Add(books[i].Title);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("DataBase Systems");
            comboBox1.Items.Add("OOP");
            comboBox1.Items.Add("Artificial Intelligence");
            
            //Add these lines in your form load method to populate your books collection

            books.Add(new Book("0201144719 9780201144710", "An Introduction to Database Systems", 0, 1, "C J Date", Convert.ToDateTime("1 jan 2015"), 1, false, "", Convert.ToDateTime("30 Nov 2015")));
            books.Add(new Book("0805301453 9780805301458", "Fundamentals of Database Systems", 0, 1, "Ramez Elmasri; Sham Navathe", Convert.ToDateTime("10 jan 2015"), 2, false, "", Convert.ToDateTime("30 Nov 2015")));
            books.Add(new Book("1571690867 9781571690869", "Object Oriented Programming in Java", 1, 2, "Stephen Gilbert; Bill McCarty", Convert.ToDateTime("15 jan 2015"), 1, false, "", Convert.ToDateTime("30 Nov 2015")));
            books.Add(new Book("1842652478 9781842652473", "Object Oriented Programming using C++", 1, 2, "B Chandra", Convert.ToDateTime("16 jan 2015"), 2, false, "", Convert.ToDateTime("30 Nov 2015")));
            books.Add(new Book("0070522618 9780070522619", "Artificial intelligence", 2, 2, "Elaine Rich", Convert.ToDateTime("20 jan 2015"), 1, false, "", Convert.ToDateTime("30 Nov 2015")));
            books.Add(new Book("0865760047 9780865760042", "The Handbook of Artificial Intelligence", 2, 2, "Avron Barr; Edward A Feigenbaum; Paul R Cohen", Convert.ToDateTime("22 jan 2015"), 0, false, "", Convert.ToDateTime("30 Nov 2015")));
            foreach(Book bk in books)
            {
                bookdic.Add(bk.Title, bk);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void edit_key_Click(object sender, EventArgs e)
        {

            if (listBox1.SelectedIndex > -1)
            {
                form_type = "edit";
                fill_in(sender, e);
            }
            else MessageBox.Show("Please Select a Book First");
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void del_key_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex > -1)
            {
                DialogResult dialogResult = MessageBox.Show("Are You sure You want to Delete this Book?", "Delete Book Entry", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes) books.Remove(bookdic[listBox1.SelectedItem.ToString()]);
                // exception handle : update the key for the dic too when editing the title name
            }
            else MessageBox.Show("Please Select a Book First");
            listBox1.Items.Remove(listBox1.SelectedItem);
        }

        private void add_key_Click(object sender, EventArgs e)
        {
            form_type = "add";
            Form1 form = new Form1(this);
            form.ShowDialog();
        }
    }
}
